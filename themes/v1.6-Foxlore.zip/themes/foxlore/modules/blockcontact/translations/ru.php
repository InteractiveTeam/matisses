<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}foxlore>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'Блок контактов';
$_MODULE['<{blockcontact}foxlore>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Позволяет вам добавлять дополнительную информацию об обслуживании клиентов';
$_MODULE['<{blockcontact}foxlore>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновлена';
$_MODULE['<{blockcontact}foxlore>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockcontact}foxlore>blockcontact_90a613a116f4bd9390ff7379a114f8d7'] = 'Блок отображает а заголовке ваш телефон (\"Звоните нам сейчас\") и ссылку на страницу \"Связаться с нами\".';
$_MODULE['<{blockcontact}foxlore>blockcontact_5f6e75192756d3ad45cff4a1ee0a45ba'] = 'Для редактирования адреса email на странице \"Связаться с нами\" вам следует открыть страницу \"Контакты\" в меню \"Клиент\".';
$_MODULE['<{blockcontact}foxlore>blockcontact_ccffe09c1cd18f73ad1f76762fded097'] = 'Для правки информации о контактах в футере откройте настройку модуля \"Блок контактной информации\"';
$_MODULE['<{blockcontact}foxlore>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'Номер телефона';
$_MODULE['<{blockcontact}foxlore>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontact}foxlore>blockcontact_52e878b67e9d94d25425231162ef5133'] = 'Здесь задаются контакты службы поддержки клиентов.';
$_MODULE['<{blockcontact}foxlore>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockcontact}foxlore>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Контакты';
$_MODULE['<{blockcontact}foxlore>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Наша горячая линия доступна круглосуточно.';
$_MODULE['<{blockcontact}foxlore>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Телефон:';
$_MODULE['<{blockcontact}foxlore>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Связаться с нашей горячей линией';
$_MODULE['<{blockcontact}foxlore>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'Обратная связь';
$_MODULE['<{blockcontact}foxlore>nav_320abee94a07e976991e4df0d4afb319'] = 'Звоните нам:';
$_MODULE['<{blockcontact}foxlore>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'Связаться с нами';
$_MODULE['<{blockcontact}foxlore>nav_9cfc9b74983d504ec71db33967591249'] = 'Связаться с нами';
