<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_8b11558e71bac59d73ad36ada02e0323'] = 'PRO контактная информация';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'Этот модуль позволит вам показывать ваш e-хранить контактную информацию в настраиваемый блок.';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновлена';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_f4f70727dc34561dfde1a3c529b6205c'] = 'Параметры';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'Название компании';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Текст';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Адрес';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_f2204a3bca22906e5d0bea697e386c7d'] = 'Номер телефона 1';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_88af1deca7c4d97a70a958842a10963a'] = 'Номер телефона 2';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Адрес';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Контакты';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_bcc254b55c4a1babdf1dcb82c207506b'] = 'Телефон';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_df1555fe48479f594280a2e03f9a8186'] = 'E-mail:';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_487aa3d82b914cc89270e3c2246eeae9'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_2bf1d5fae1c321d594fdedf05058f709'] = 'Адрес:';
$_MODULE['<{problockcontactinfos}foxlore>problockcontactinfos_673ae02fffb72f0fe68a66f096a01347'] = 'Телефон:';
