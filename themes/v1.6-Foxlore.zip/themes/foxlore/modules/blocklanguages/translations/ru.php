<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}foxlore>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Блок выбора языка';
$_MODULE['<{blocklanguages}foxlore>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Добавляет блок, позволяющий посетителям выбирать язык магазина.';
$_MODULE['<{blocklanguages}foxlore>blocklanguages_4994a8ffeba4ac3140beb89e8d41f174'] = 'Язык';
