<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Блок информации о пользователе';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Добавляет блок, который отображает информацию о клиенте.';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_0c3bf3014aafb90201805e45b5e62881'] = 'Посмотреть корзину';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Корзина:';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_deb10517653c255364175796ace3553f'] = 'Товар';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'Товары';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(пусто)';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_2cbfb6731610056e1d0aaacde07096c1'] = 'Просмотреть мою учетную запись покупателя';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Личный кабинет';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Добро пожаловать';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Выйти';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_c87aacf5673fada1108c9f809d354311'] = 'Выйти';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_d4151a9a3959bdd43690735737034f27'] = 'Войти в учетную запись покупателя';
$_MODULE['<{blockuserinfo}foxlore>blockuserinfo_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Войти';
$_MODULE['<{blockuserinfo}foxlore>nav_2cbfb6731610056e1d0aaacde07096c1'] = 'Просмотреть мою учетную запись покупателя';
$_MODULE['<{blockuserinfo}foxlore>nav_4b877ba8588b19f1b278510bf2b57ebb'] = 'Выйти';
$_MODULE['<{blockuserinfo}foxlore>nav_c87aacf5673fada1108c9f809d354311'] = 'Выйти';
$_MODULE['<{blockuserinfo}foxlore>nav_d4151a9a3959bdd43690735737034f27'] = 'Войти в учетную запись покупателя';
$_MODULE['<{blockuserinfo}foxlore>nav_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Войти';
$_MODULE['<{blockuserinfo}foxlore>nav_09a763df3edf590f70369bf8f7b65222'] = 'Список ссылок пользователя';
$_MODULE['<{blockuserinfo}foxlore>nav_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Аккаунт';
$_MODULE['<{blockuserinfo}foxlore>nav_7ec9cceb94985909c6994e95c31c1aa8'] = 'Мой список желаний';
$_MODULE['<{blockuserinfo}foxlore>nav_e0fd9b310aba555f96e76738ff192ac3'] = 'Мои желания';
$_MODULE['<{blockuserinfo}foxlore>nav_4394c8d8e63c470de62ced3ae85de5ae'] = 'Выйти';
$_MODULE['<{blockuserinfo}foxlore>nav_99dea78007133396a7b8ed70578ac6ae'] = 'Войти';
