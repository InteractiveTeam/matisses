<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_a982177e7076ebacec307f79427dcd42'] = 'Facebook Like Box';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_ff393bd04db641576ffe7d89f80506e5'] = 'Положите вашу Facebook фан-страницу как на сайте окна.';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_c888438d14855d7d96a2724ee9c306bd'] = 'Параметры обновлен';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_f4f70727dc34561dfde1a3c529b6205c'] = 'Параметры';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_c69aeb53eedc2fa30c68f2e6c8001666'] = 'Заголовок Окна';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_0dd14cca9b5816a7739863b4aad3f0f3'] = 'Заголовок коробка на первой странице';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_448134d726e7dd7b6632632a6eb7b331'] = 'Заголовок страницы';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_5a90b2d806c0d2836cb45d14b8bff7fe'] = 'Facebook странице';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_e6e21834c0bb21375af34dd6bc2671c4'] = 'Лицо число';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_0f6bb87b7e9a2f3b4d4587448cd8707a'] = 'Отрезка видимых граней';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_83cccf4d0f83339c027ad7395fa4d0b9'] = 'Показать лица';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_9135ffc9302969b25783e16be95a7d53'] = 'Посмотреть название компании';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_d915a10f30d78bc8f68a0b278a3267ac'] = 'Показать Логотип Компании';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_06933067aafd48425d67bcb01bba5cb6'] = 'Обновление';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_5023a0829879deb8e80d2be0364fa5b2'] = 'Очистить кэш';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_98b82c200a2e309b24cb481970f3fcc4'] = 'Нравится';
$_MODULE['<{blockfacebooklike}foxlore>blockfacebooklike_c9fee138bfe3fbd940f268b63a5bcca1'] = '%s человек(а),  которым нравится';
