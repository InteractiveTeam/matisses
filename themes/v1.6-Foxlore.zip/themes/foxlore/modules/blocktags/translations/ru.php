<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}foxlore>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Блок тегов';
$_MODULE['<{blocktags}foxlore>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'Добавляет блок, отображающий тэги продуктов.';
$_MODULE['<{blocktags}foxlore>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'Пожалуйста, заполните поле «Показанные тэги\".';
$_MODULE['<{blocktags}foxlore>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Неверный номер.';
$_MODULE['<{blocktags}foxlore>blocktags_fb3855930920fd1ef34c4904ef230802'] = 'Пожалуйста заполните поле \"Уровни тегов\".';
$_MODULE['<{blocktags}foxlore>blocktags_feb6da9d1dab0d22293d1da205fa1bb2'] = 'Неверное значение поля \"Уровни Тегов\". Выберите положительное целое число.';
$_MODULE['<{blocktags}foxlore>blocktags_08d5df9c340804cbdd62c0afc6afa784'] = 'Пожалуйста, заполните поле \"В случайном порядке\".';
$_MODULE['<{blocktags}foxlore>blocktags_5c35c840e2d37e5cb3b6e1cf8aa78880'] = 'Неверное значение \"В случайном порядке\". Должно быть логическое.';
$_MODULE['<{blocktags}foxlore>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blocktags}foxlore>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blocktags}foxlore>blocktags_726cefc6088fc537bc5b18f333357724'] = 'Показанные тэги';
$_MODULE['<{blocktags}foxlore>blocktags_34a51d24608287f9b34807c3004b39d9'] = 'Задайте количество тегов, которые вы хотите отображать в этом блоке. (по умолчанию: 10)';
$_MODULE['<{blocktags}foxlore>blocktags_ed7a7c842913f44b32b0f06d5a369dcf'] = 'Уровни тегов';
$_MODULE['<{blocktags}foxlore>blocktags_d088d9f9a8634d69a2aa0b11883fb6b1'] = 'Задайте количество уровней используемых тегов. (по умолчанию: 3)';
$_MODULE['<{blocktags}foxlore>blocktags_ac5bf3b321fa29adf8af5c825d670e76'] = 'В случайном порядке';
$_MODULE['<{blocktags}foxlore>blocktags_d4a9f41f7f8d2a65cda97d8b5eb0c9d5'] = 'Если включено, теги показываются в случайном порядке. По умолчанию выключено, и самые популярные теги отображаются первыми.';
$_MODULE['<{blocktags}foxlore>blocktags_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blocktags}foxlore>blocktags_b9f5c797ebbf55adccdd8539a65a0241'] = 'Выключено';
$_MODULE['<{blocktags}foxlore>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blocktags}foxlore>blocktags_189f63f277cd73395561651753563065'] = 'Тэги';
$_MODULE['<{blocktags}foxlore>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Подробнее о';
$_MODULE['<{blocktags}foxlore>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Метки пока не установлены';
$_MODULE['<{blocktags}foxlore>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Тэги еще не созданы';
