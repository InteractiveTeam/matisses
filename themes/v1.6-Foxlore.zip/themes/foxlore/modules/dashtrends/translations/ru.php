<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{dashtrends}foxlore>dashtrends_ee653ade5f520037ef95e9dc2a42364c'] = 'Панель трендов';
$_MODULE['<{dashtrends}foxlore>dashtrends_f2d0efa68eb71bfd5209abeb9f4b0943'] = 'Добавляет блок с графическим представлением развития вашего магазина(ов) На основе выбранных ключевых данных.';
$_MODULE['<{dashtrends}foxlore>dashtrends_2d125dc25b158f28a1960bd96a9fa8d1'] = '%s очков';
$_MODULE['<{dashtrends}foxlore>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Продажи';
$_MODULE['<{dashtrends}foxlore>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Заказы';
$_MODULE['<{dashtrends}foxlore>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Средняя корзина';
$_MODULE['<{dashtrends}foxlore>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Посещения';
$_MODULE['<{dashtrends}foxlore>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Конверсия';
$_MODULE['<{dashtrends}foxlore>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Чистая прибыль';
$_MODULE['<{dashtrends}foxlore>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (предыдущий период)';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Обзор';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Настроить';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Обновить';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_e537825dd409a90ef70d8c2eb56122a1'] = 'Сумма выручки (без НДС). налог), создаваемого в пределах диапазона дат по заказам считать проверенным.';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Продажи';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_8bc1c5ca521b99b87908db0bcd33ec76'] = 'Общее количество подтвержденных заказов за указанный промежуток времени.';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Заказы';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_f15f2a2bf99d3dcad2cba1a2c615b9dc'] = 'Среднее значение корзину-это показатель, представляющий стоимость среднего заказа в пределах диапазона дат. Он рассчитывается путем деления продаж по заказам.';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Значение корзины';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_4f631447981c5fa240006a5ae2c4b267'] = 'Общее число посещений в пределах диапазона дат. Визит-это период времени, пользователь активно взаимодействует с вашего сайта.';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Посещения';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_7a6e858f8c7c0b78fb4d43cefcb8c017'] = 'Коэффициент конверсии для электронной торговли-это процент посещений, в результате подтверждены заказ.';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Конверсия';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_8dedc1b3ee3a92212fb5b5acad7f207f'] = 'Чистая прибыль-это мера прибыльности предприятия после учета всех Ecommerce расходы. Вы можете предоставить эти расходы, нажав на иконку настройки прямо над здесь.';
$_MODULE['<{dashtrends}foxlore>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Чистая прибыль';
