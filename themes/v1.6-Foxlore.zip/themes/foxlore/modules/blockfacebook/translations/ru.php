<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockfacebook}foxlore>blockfacebook_43d541d80b37ddb75cde3906b1ded452'] = 'Блок подписки на Facebook';
$_MODULE['<{blockfacebook}foxlore>blockfacebook_e2887a32ddafab9926516d8cb29aab76'] = 'Отображает блок для подписки на вашу страницу в Facebook.';
$_MODULE['<{blockfacebook}foxlore>blockfacebook_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновлена';
$_MODULE['<{blockfacebook}foxlore>blockfacebook_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockfacebook}foxlore>blockfacebook_c98cf18081245e342d7929c117066f0b'] = 'Ссылка на Facebook (требуется полный URL)';
$_MODULE['<{blockfacebook}foxlore>blockfacebook_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockfacebook}foxlore>blockfacebook_374fe11018588d3d27e630b2dffb7909'] = 'Подписаться на наши публикации в Facebook';
$_MODULE['<{blockfacebook}foxlore>preview_31fde7b05ac8952dacf4af8a704074ec'] = 'Просмотр';
$_MODULE['<{blockfacebook}foxlore>preview_374fe11018588d3d27e630b2dffb7909'] = 'Подписаться на наши публикации в Facebook';
