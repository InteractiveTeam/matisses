<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{dinterval}foxlore>dinterval_a2ffb7717dc3b51c2084899b725b65f6'] = 'DInterval';
$_MODULE['<{dinterval}foxlore>dinterval_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Настройки';
$_MODULE['<{dinterval}foxlore>dinterval_06cd28c646796eb8ffc52fa08ee2f799'] = 'Дата начала';
$_MODULE['<{dinterval}foxlore>dinterval_7d6da8f6cb6897fb1a8ce7f74e826c2e'] = 'Дата  окончания';
$_MODULE['<{dinterval}foxlore>dinterval_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{dinterval}foxlore>home_44fdec47036f482b68b748f9d786801b'] = 'дней';
$_MODULE['<{dinterval}foxlore>home_73cdddd7730abfc13a55efb9f5685a3b'] = 'часов';
$_MODULE['<{dinterval}foxlore>home_640fd0cc0ffa0316ae087652871f4486'] = 'минут';
$_MODULE['<{dinterval}foxlore>home_783e8e29e6a8c3e22baa58a19420eb4f'] = 'секунд';
